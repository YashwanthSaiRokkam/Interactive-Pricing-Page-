function selectPlan(planId) {
    // Remove selected class from all plans
    document.querySelectorAll('.pricing-plan').forEach(plan => {
        plan.classList.remove('selected');
    });

    // Add selected class to the clicked plan
    document.getElementById(planId).classList.add('selected');

    // Show confirmation message
    alert('Plan selected: ' + planId);
}
